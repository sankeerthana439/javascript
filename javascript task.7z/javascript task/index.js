const form = document.getElementById('form');
const username = document.getElementById('username');
const mobile = document.getElementById('mobile');
const dob = document.getElementById('dob');
const email = document.getElementById('email');


form.addEventListener('submit',(e) => {
  e.preventDefault();
  
  checkInputs();
});
 
function checkInputs(){
  //get the values from the inputs
  const usernameValue = username.value.trim();
  const mobileValue = mobile.value.trim();
  const dobValue = dob.value.trim();
  const emailValue = email.value.trim();

  
  if(usernameValue === ''){
    setErrorFor(username, 'Username cannot be blank');
  } else{
    setSuccessFor(username);
  }
  
  if(mobileValue === ''){
    setErrorFor(mobile, 'Mobile Number cannot be blank');
  } else{
    setSuccessFor(mobile);
  }
  
  if(dobValue === ''){
    setErrorFor(dob, 'Username cannot be blank');
  } else{
    setSuccessFor(dob);
  }
  
  if(emailValue === ''){
    setErrorFor(email, 'Email cannot be blank');
  } else if(!isEmail(emailValue)){
    setErrorFor(email,'Email is not valid');    
  }  else {
    setSuccessFor(email)
  }

}


function setErrorFor(input,message){
  const formControl = input.parentElement; // form-control
  const small = formControl.querySelector('small');
  
  //add error message inside small
  small.innerText = message;
  
  // add error class
  formControl.className = 'form-control error';
}

function setSuccessFor(input){
  const formControl = input.parentElement;
  formControl.className = 'form-control success';
}

function isEmail(email){
  return /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(email);
}